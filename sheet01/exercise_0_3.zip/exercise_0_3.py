""" Dylan Baumgartner
Sage Leone
Niklas Schmatloch """

if __name__ == "__main__":
    print("Copy the solution of another exercise group.")
    print("Copy from the sample solution of previous years.")
    print("Altering existing code by renaming variables or swapping lines where possible.")

